JobPulse — short LinkedIn demo

Video: JobPulse-LinkedIn-short-demo.mp4
Duration: 40 seconds
Format: 1920 × 1080, H.264 MP4, 30 fps, fast-start playback
Audio: silent; animated chapter captions support autoplay without sound
Cover: JobPulse-short-cover-HD.png
Post text: LinkedIn-caption.txt (review and personalize before publishing)

Shows the current application UI: home, login, job filtering, resume upload, matching, reviewed saved drafts, Word export, user-reported application tracking, notes and preferences.

Disclosure:
The recording uses demonstration data and staged API responses, including a simulated AI response. No real employer application was submitted. No claim is made that automatic submissions or free-form factual AI rewriting are finished. Backend functionality has separate automated verification; this video is a staged product walkthrough rather than a live-service acceptance test.

The application source was not modified for this recording. No paid service was used and nothing was posted to LinkedIn automatically.

Posting:
Upload the MP4 directly to LinkedIn. Choose the HD PNG cover as its thumbnail where supported; otherwise select the opening title frame. Use the supplied caption as a starting point.
